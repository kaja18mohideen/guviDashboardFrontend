import React from 'react';
import './styles/WebCode.css';

const WebCode = () => {
  return (
    <div className="webcode-container">
      <p>No web code available right now.</p>
    </div>
  );
};

export default WebCode;
