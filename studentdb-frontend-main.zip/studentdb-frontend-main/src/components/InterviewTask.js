import React from 'react';
import './styles/InterviewTask.css';

const InterviewTask = () => {
  return (
    <div className="page-container">
      <p>No records</p>
    </div>
  );
};

export default InterviewTask;
