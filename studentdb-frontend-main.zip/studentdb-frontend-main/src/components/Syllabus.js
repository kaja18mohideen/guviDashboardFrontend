import React from 'react';
import './styles/Syllabus.css';

const Syllabus = () => {
  return (
    <div className="page-container">
      <h2>Syllabus Page</h2>
      <p>No content available yet.</p>
    </div>
  );
};

export default Syllabus;
