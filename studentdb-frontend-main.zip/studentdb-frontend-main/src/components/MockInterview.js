import React from 'react';
import './styles/MockInterview.css';

const MockInterview = () => {
  return (
    <div className="page-container">
      <h2>Mock Interview Page</h2>
      <p>No content available yet.</p>
    </div>
  );
};

export default MockInterview;
