import React from 'react';
import './styles/Application.css';

const Application = () => {
  return (
    <div className="page-container">
      <p>No Applications Found</p>
    </div>
  );
};

export default Application;
