import React from 'react';
import './styles/Requirement.css';

const Requirement = () => {
  return (
    <div className="page-container">
      <p>Content available only for Placement Interested Students.</p>
    </div>
  );
};

export default Requirement;
