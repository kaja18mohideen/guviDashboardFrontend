import React from 'react';
import './styles/Testimonial.css';

const Testimonial = () => {
  return (
    <div className="page-container">
      <h2>Testimonial Page</h2>
      <p>No content available yet.</p>
    </div>
  );
};

export default Testimonial;
