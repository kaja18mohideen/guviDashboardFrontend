import React from 'react';
import './styles/PlacementBoard.css';

const PlacementBoard = () => {
  return (
    <div className="page-container">
      <h2>Placement Board Page</h2>
      <p>No content available yet.</p>
    </div>
  );
};

export default PlacementBoard;
