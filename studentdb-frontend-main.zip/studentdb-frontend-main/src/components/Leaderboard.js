import React from 'react';
import './styles/Leaderboard.css';

const Leaderboard = () => {
  return (
    <div className="page-container">
      <h2>Leaderboard Page</h2>
      <p>No content available yet.</p>
    </div>
  );
};

export default Leaderboard;
